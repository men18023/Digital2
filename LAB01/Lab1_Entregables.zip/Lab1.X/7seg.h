/* 
 * File:   7seg.h
 * Author: jonam
 *
 * Created on 19 de julio de 2021, 02:51 PM
 */

#ifndef _7SEG_H
#define	_7SEG_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h>

char display(char hex);

#endif	/* 7SEG_H */

