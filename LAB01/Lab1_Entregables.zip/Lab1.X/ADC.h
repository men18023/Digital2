/* 
 * File:   ADC.h
 * Author: jonam
 *
 * Created on 19 de julio de 2021, 01:42 PM
 */

#ifndef ADC_H
#define	ADC_H

#include <xc.h>
#include <stdint.h>

uint8_t valor_ADC();
void conADC(void);

#endif	/* ADC_H */

